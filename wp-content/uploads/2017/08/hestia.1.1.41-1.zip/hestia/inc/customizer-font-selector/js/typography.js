( function($) {

	$( document ).ready(function () {

		$( '.hestia-typography-select' ).hestiaSelect();

	} );

} )( jQuery );